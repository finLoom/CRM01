// Sample content for routes.js
