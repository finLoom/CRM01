// Sample content for validators.js
