// Sample content for formatters.js
