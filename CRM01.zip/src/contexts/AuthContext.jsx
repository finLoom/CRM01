// Sample content for AuthContext.jsx
