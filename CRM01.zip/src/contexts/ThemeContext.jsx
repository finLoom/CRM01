// Sample content for ThemeContext.jsx
