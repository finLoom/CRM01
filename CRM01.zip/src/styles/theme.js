// Sample content for theme.js
