// Sample content for api.js
