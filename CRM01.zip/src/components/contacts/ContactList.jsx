// Sample content for ContactList.jsx
