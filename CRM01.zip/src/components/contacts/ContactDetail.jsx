// Sample content for ContactDetail.jsx
