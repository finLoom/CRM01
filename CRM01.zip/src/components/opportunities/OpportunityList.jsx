// Sample content for OpportunityList.jsx
