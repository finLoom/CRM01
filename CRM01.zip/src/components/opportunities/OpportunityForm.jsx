// Sample content for OpportunityForm.jsx
