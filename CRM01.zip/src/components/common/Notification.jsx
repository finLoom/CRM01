// Sample content for Notification.jsx
