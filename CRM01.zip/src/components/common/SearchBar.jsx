// Sample content for SearchBar.jsx
