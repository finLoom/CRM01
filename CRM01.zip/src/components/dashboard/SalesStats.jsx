// Sample content for SalesStats.jsx
