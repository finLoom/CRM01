// Sample content for ActivityFeed.jsx
