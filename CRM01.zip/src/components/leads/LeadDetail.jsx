// Sample content for LeadDetail.jsx
